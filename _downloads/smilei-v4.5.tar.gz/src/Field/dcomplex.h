#ifndef DCOMPLEX_H_
#define DCOMPLEX_H_
#define Icpx dcomplex(0.0,1.0)
typedef std::complex<double> dcomplex;
#endif /* DCOMPLEX_H_ */
